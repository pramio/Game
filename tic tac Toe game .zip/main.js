document.addEventListener("DOMContentLoaded", () => {
    const board = document.querySelectorAll(".cell");
    const message = document.getElementById("message");
    const restartButton = document.getElementById("restart");
    const modeSelector = document.getElementById("mode");
    const scoreX = document.getElementById("scoreX");
    const scoreO = document.getElementById("scoreO");
    let currentPlayer = "X";
    let gameActive = true;
    let gameMode = modeSelector.value;
    let boardState = ["", "", "", "", "", "", "", "", ""];
    const winningCombinations = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];
    let score = { X: 0, O: 0 }; // Scoreboard

    // Handle cell click
    board.forEach(cell => cell.addEventListener("click", handleCellClick));

    function handleCellClick(event) {
        const cellIndex = event.target.getAttribute("data-index");

        if (boardState[cellIndex] !== "" || !gameActive) {
            return;
        }

        updateCell(event.target, cellIndex);
        checkResult();

        if (gameActive && gameMode === "single") {
            setTimeout(aiMove, 500); // AI turn delay
        }
    }

    // Update cell
    function updateCell(cell, index) {
        boardState[index] = currentPlayer;
        cell.textContent = currentPlayer;
        currentPlayer = currentPlayer === "X" ? "O" : "X";
    }

    // Check result
    function checkResult() {
        let roundWon = false;
        let winningCombination = null;
        for (let i = 0; i < winningCombinations.length; i++) {
            const winCondition = winningCombinations[i];
            let a = boardState[winCondition[0]];
            let b = boardState[winCondition[1]];
            let c = boardState[winCondition[2]];
            if (a === "" || b === "" || c === "") {
                continue;
            }
            if (a === b && b === c) {
                roundWon = true;
                winningCombination = winCondition; // Store winning combination
                break;
            }
        }

        if (roundWon) {
            message.textContent = `Player ${currentPlayer === "X" ? "O" : "X"} Wins!`;
            gameActive = false;
            score[currentPlayer === "X" ? "O" : "X"]++;
            updateScoreboard();
            highlightWinningCells(winningCombination);
            return;
        }

        if (!boardState.includes("")) {
            message.textContent = "It's a Draw!";
            gameActive = false;
            return;
        }
    }

    // Highlight winning cells
    function highlightWinningCells(winningCombination) {
        winningCombination.forEach(index => {
            board[index].classList.add('win'); // Add win class to winning cells
        });
    }

    // Update the scoreboard
    function updateScoreboard() {
        scoreX.textContent = score.X;
        scoreO.textContent = score.O;
    }

    // AI Move using Minimax algorithm
    function aiMove() {
        const bestMove = minimax(boardState, "O").index;
        updateCell(board[bestMove], bestMove);
        checkResult();
    }

    function minimax(newBoard, player) {
        const availableSpots = newBoard.reduce((acc, el, idx) => el === "" ? acc.concat(idx) : acc, []);

        if (checkWinner(newBoard, "X")) return { score: -10 };
        if (checkWinner(newBoard, "O")) return { score: 10 };
        if (availableSpots.length === 0) return { score: 0 };

        const moves = [];
        availableSpots.forEach(spot => {
            const move = {};
            move.index = spot;
            newBoard[spot] = player;

            if (player === "O") {
                const result = minimax(newBoard, "X");
                move.score = result.score;
            } else {
                const result = minimax(newBoard, "O");
                move.score = result.score;
            }

            newBoard[spot] = "";
            moves.push(move);
        });

        let bestMove;
        if (player === "O") {
            let bestScore = -Infinity;
            moves.forEach((move, idx) => {
                if (move.score > bestScore) {
                    bestScore = move.score;
                    bestMove = idx;
                }
            });
        } else {
            let bestScore = Infinity;
            moves.forEach((move, idx) => {
                if (move.score < bestScore) {
                    bestScore = move.score;
                    bestMove = idx;
                }
            });
        }

        return moves[bestMove];
    }

    function checkWinner(board, player) {
        return winningCombinations.some(combination =>
            combination.every(index => board[index] === player)
        );
    }

    // Restart Game
    restartButton.addEventListener("click", () => {
        boardState = ["", "", "", "", "", "", "", "", ""];
        board.forEach(cell => {
            cell.textContent = "";
            cell.classList.remove('win'); // Remove win class
        });
        currentPlayer = "X";
        gameActive = true;
        message.textContent = "";
    });

    // Change Game Mode
    modeSelector.addEventListener("change", (e) => {
        gameMode = e.target.value;
        restartButton.click();
    });
});
